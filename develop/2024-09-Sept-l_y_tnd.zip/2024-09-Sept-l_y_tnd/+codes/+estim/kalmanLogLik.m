function loglik = kalmanLogLik(m, loglikInputs)

loglik = implementKalmanFilter(m, loglikInputs);

end