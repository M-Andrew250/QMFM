function writeMessage(msg, varargin)

fprintf(msg + "\n", varargin{:});

end