function plotPriorPosterior(chain, N)



end